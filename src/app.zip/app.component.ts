import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: ['body {height: 100%; width: 100%;color: #fff; }',
  '.menu{ height: 100%; width: 100%; }']
})
export class AppComponent {
  title = '我是徐晓飞，是一名程序员';
}
