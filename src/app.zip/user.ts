export class UserInfo {
	constructor(
		public email: string,
		public password: string,
		public repassword: string
	) { }
}
