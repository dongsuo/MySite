var Response = (function () {
    function Response(type, room, name, data) {
        this.type = type;
        this.room = room;
        this.name = name;
        this.data = data;
    }
    return Response;
}());
export { Response };
//# sourceMappingURL=chatResponse.js.map