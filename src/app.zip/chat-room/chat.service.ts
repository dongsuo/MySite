
import { Injectable,NgZone } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import * as io from "socket.io-client";

var ioFunc = (io as any).default ? (io as any).default : io;

@Injectable()
export class MessageService {
  private url = 'ws://xiaofeixu.cn';

  private socket:SocketIOClient.Socket;
  constructor(private ngZone:NgZone) {
    // this.socket = io(this.url)
   }
   chat = new Observable(observer=>{
    this.socket = ioFunc(this.url,{
      path:'/chat',
      reconnection :true,
      reconnectionAttempts:5
    })
    this.socket.on('message',(message:Object)=>{
      // console.log(message)
      observer.next(message)
    })
    this.socket.on('joinResult',(joinResult:Object)=>{
      console.log(joinResult)
      observer.next(joinResult)
    })
    this.socket.on('nameResult',(nameResult:Object)=>{
      console.log(nameResult)
      observer.next(nameResult)
    })
    this.socket.on('roomList',(roomList:Object)=>{
      console.log(roomList)
      observer.next(roomList)
    })
    this.socket.on('disconnect',()=>{
      console.log('disconnected')
    })
  })
   send(message:String){
    //  console.log(message)
    this.socket.emit('message',message)
   }
   changeName(name:String){
    //  console.log(name);
     this.socket.emit('changeName',name)
   }
   addRoom(room:String){
    this.socket.emit('newRoom',room)
   }
}
