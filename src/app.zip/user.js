var UserInfo = (function () {
    function UserInfo(email, password, repassword) {
        this.email = email;
        this.password = password;
        this.repassword = repassword;
    }
    return UserInfo;
}());
export { UserInfo };
//# sourceMappingURL=user.js.map